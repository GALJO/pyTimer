from setuptools import setup, find_packages

setup(
    name='pyTimer',
    version='1.0',
    author='Jan Olenski',
    author_email='jasiek.ole@gmail.com',
    license='DoWhateverUWant0.0',
    description='This lib contains advanced timer',
    packages=find_packages()
)

